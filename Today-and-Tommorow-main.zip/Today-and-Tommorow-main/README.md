# Today-and-Tommorow
<!DOCTYPE html>
</body>
</html>
<html>
<head>
<p align="center"><S>"Yesterday is not ours to recover, but tomorrow is ours to win or lose"<br> -Lyndon B Johnson...</S>
<h4><p>Covid...Covid is everywhere, chaos and death everywhere,<br> That, That is what happening to the world at the moment.<br> for more information Coronaviruses are a large family of zoonotic viruses that cause illness ranging from,<br> the common cold to severe respiratory diseases.<br>Zoonotic means these viruses are able to be transmitted from animals to humans.<br>There are several coronaviruses known to be circulating in different animal populations that have not yet infected humans.<br>COVID-19 is the most recent to make the jump to human infection. </p></h4> 
<p align="center"><b>America, China , Russia , Japan, You name it,all over the world are dealing with covid.<br> People are struggling and suffering as their lives goes on by this pandemic .<br> Everyone prays  to God for safety and everything else. But as time goes on,<br> Some people live their lives with chaos while there are those who dont give a damn<br> about the pandemic and there are those who live with no problems</b>
<b>And the fact that there are people <br>who dont take covid seriously is devastating because<br> covid is literally a few meters away from going inside of us <br>and could kill us any time, And when we get symptoms from it,<br>It could either mean death or stay alive, and if we really escaped death, we'd have to pay money that we could die from.<br> The payment from being treated well from covid is  very expensive and there are those people who got infected that got treated but,<br> doesnt have the money to pay it all.</b>
<b> And so, What ever is happening right now,<br> everything is a mess and Fine at the same time,<br> but we shouldnt use this time in pandemic as nothing but to stay in the house and do nothing but we should also learn from it, <br> learn other people's lives,Improve our skills, Adapt to our life inside our house for a year, and etc.</b></p>

<!DOCTYPE html>
<html>
<head>


</head>
<body>

<h2>Covid-19</h2>

<table>
  <tr>
    <th>Cases</th>
    <th>Deaths</th>
    <th>Recovered</th>
    <th>Months</th>
  </tr>
  <tr>
    <td>62,844,837</td>
    <td>1,465,144</td>
    <td>2.87%</td>
    <td>December</td>
  </tr>
  <tr>
    <td>45,968,798</td>
    <td>1,192,911</td>
    <td>3.32%</td>
    <td>November</td>
  </tr>
  <tr>
    <td>33,846,093</td>
    <td>1,010,639</td>
    <td>3.70%</td>
    <td>October</td>
  </tr>
  <tr>
    <td>25,356,942</td>
    <td>848,445</td>
    <td>4.39%</td>
    <td>September</td>
  </tr>
  <tr>
    <td>17,396,943</td>
    <td>675,060</td>
    <td>5.47%</td>
    <td>August</td>
  </tr>
</table>

<p><b>Total Cases:113M Total Recovered:63.5M Total Deaths:2.5M</p></b>
<b> And in the course of 5 months that much already happend.<br>Hope is defined by different People and Nations but<br> hope for me is never giving up for what is right and also hope gives us motivation and makes us feel comfortable for ourselves.<br>  And Hope can come in any form or shape or word.<br> And so, Dove is a symbol that represents purity, gentleness, devotion, beauty, and faith.<br> And the rainbow makes it so that the dove flying towards us against the rainbow look as if we are seeing hope.<br> And to those who loss almost everything because of this pandemic we shouldn’t really put our attention to what’s now but to what’s coming for the future.
<h6> <U> Groupmates:Vincent Jimera<br>Wren Berden<br>Karl Padilla<br> Clijster Chua</h6></U>
                    

</body>
</html>
         
